package com.example.rocnikovka2;

public class Income {

    public String category;
    public float amount;
    public String date;

    public Income(String date, String category, float amount) {

        this.category = category;
        this.amount = amount;
        this.date = date;

    }

    public String getCategory() {
        return category;
    }

    public float getAmount() {
        return amount;
    }

    public String getDate() {
        return date;
    }
}
