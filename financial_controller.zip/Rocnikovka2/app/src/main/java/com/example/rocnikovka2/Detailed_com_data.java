package com.example.rocnikovka2;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.design.widget.TextInputLayout;
import android.util.Log;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

public class Detailed_com_data extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    Button compare_button;
    TextInputLayout txt_com1_year, txt_com2_year;
    TextView editText1_com_year,editText2_com_year;
    Spinner month_spinner, month2_spinner, category_spinner;
    ArrayList<String> categories;
    DHelper2 data_helper;
    String month1, month2,category;
    BarChart barChart;
    Toast tag;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detailed_com_data);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        tag = Toast.makeText(this, "Write the year in the text field",Toast.LENGTH_LONG);

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        compare_button = (Button) findViewById(R.id.com_button);

        data_helper = new DHelper2(this);
        txt_com1_year = (TextInputLayout) findViewById(R.id.txt1_com_year);
        txt_com2_year = (TextInputLayout) findViewById(R.id.txt2_com_year);

        editText1_com_year = (TextView) findViewById(R.id.editText1_com_year);
        editText2_com_year = (TextView) findViewById(R.id.editText2_com_year);

        month_spinner = (Spinner) findViewById(R.id.month1_spinner);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.months, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        month_spinner.setAdapter(adapter);
        month_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long id) {
                 month1 = adapterView.getItemAtPosition(i).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });



        month2_spinner = (Spinner) findViewById(R.id.month2_spinner);
        month2_spinner.setAdapter(adapter);

        month2_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long id) {
                month2 = adapterView.getItemAtPosition(i).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        category_spinner = (Spinner) findViewById(R.id.cat1_spinner);
        categories = data_helper.getCategories();
        ArrayAdapter<String> catAdapter = new ArrayAdapter<>(this,android.R.layout.simple_spinner_item,categories);
        category_spinner.setAdapter(catAdapter);

        category_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long id) {
                category = adapterView.getItemAtPosition(i).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        compare_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                int input1 = 0;
                int input2 = 0;
                ArrayList<BarDataSet> arr_set = new ArrayList<>();
                BarData barData = new BarData();
                if(!(txt_com1_year.getEditText().getText().toString().isEmpty())||(txt_com2_year.getEditText().getText().toString().isEmpty())) {
                    try {
                        input1 = data_helper.displayMonthCategoryYearData(month1,txt_com1_year.getEditText().getText().toString(),category);
                        input2 = data_helper.displayMonthCategoryYearData(month2,txt_com2_year.getEditText().getText().toString(),category);

                        barChart = (BarChart) findViewById(R.id.com_barChart);
                        BarEntry entry1 = new BarEntry(1,input1);
                        ArrayList<BarEntry> barEntries = new ArrayList<>();
                        barEntries.add(entry1);
                        BarDataSet barSet = new BarDataSet( barEntries,month1 + " "+txt_com1_year.getEditText().getText().toString());
                        barSet.setColor(Color.BLUE);

                        BarEntry entry2 = new BarEntry(2,input2);
                        ArrayList<BarEntry> barEntries2 = new ArrayList<>();
                        barEntries2.add(entry2);
                        BarDataSet barSet2 = new BarDataSet( barEntries2,month2 + " "+txt_com2_year.getEditText().getText().toString());
                        barSet2.setColor(Color.RED);

                        barData.addDataSet(barSet);
                        barData.addDataSet(barSet2);

                        barChart.setData(barData);
                        barChart.invalidate();


                    } catch (ParseException e) {
                        e.printStackTrace();
                    }
                }else tag.show();

            }
        });




    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.detailed_com_data, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_outcomes) {
            // Handle the camera action
            Intent i = new Intent(Detailed_com_data.this, Expenses_activity.class);
            startActivity(i);
        } else if (id == R.id.nav_home) {
            Intent i = new Intent(Detailed_com_data.this, MainActivity.class);
            startActivity(i);

        } else if (id == R.id.nav_data) {
            Intent i = new Intent(Detailed_com_data.this, History_data_activity.class);
            startActivity(i);

        } else if (id == R.id.nav_currency) {
            Intent i = new Intent(Detailed_com_data.this, Converter.class);
            startActivity(i);

        } else if (id == R.id.nav_income) {
            Intent i = new Intent(Detailed_com_data.this, Income_activity.class);
            startActivity(i);

        }
        else if (id == R.id.nav_detail) {
            Intent i = new Intent(Detailed_com_data.this, DataViewer.class);
            startActivity(i);
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

}
