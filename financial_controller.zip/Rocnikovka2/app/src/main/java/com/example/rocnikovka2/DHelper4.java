package com.example.rocnikovka2;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class DHelper4 extends SQLiteOpenHelper {
    private static final String TABLE_NAME = "balanceHistory";
    private static final String col1 = "balance_id";
    private static final String col2 = "balance_amount";


    public DHelper4(Context context) {
        super(context, TABLE_NAME, null, 1);


    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        String createTable = "CREATE TABLE " + TABLE_NAME + "(" + col1 + "INTEGER PRIMARY KEY, " + col2 + " TEXT" + ")";
        sqLiteDatabase.execSQL(createTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }

    public void addData(Balance income) {

        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        contentValues.put(col2, income.getBalance());

        sqLiteDatabase.insert(TABLE_NAME, null, contentValues);
        sqLiteDatabase.close();
    }


    public float displayLastBalance() {
        ArrayList<Balance> list = new ArrayList<>();

        String selectQuery = "SELECT * FROM " + TABLE_NAME;

        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        Cursor cursor = sqLiteDatabase.rawQuery(selectQuery, null);

        if (cursor.moveToFirst()) {
            do {
                Balance in = new Balance(Float.parseFloat(cursor.getString(1)));
                list.add(in);

            } while (cursor.moveToNext());

        }

        return list.get(list.size() - 1).getBalance();



    }

    public ArrayList<Float> displayAllData() {
        ArrayList<Balance> list = new ArrayList<>();
        ArrayList<Float> arr_list = new ArrayList<>();

        String selectQuery = "SELECT * FROM " + TABLE_NAME;

        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        Cursor cursor = sqLiteDatabase.rawQuery(selectQuery, null);
        int y = 0;
        int x = 0;
        if (cursor.moveToFirst()) {
            do {
                Balance in = new Balance(Float.parseFloat(cursor.getString(1)));
                list.add(in);
                arr_list.add(list.get(list.size()-1).getBalance());
            } while (cursor.moveToNext());
        }

        for(Balance b:list){
            x++;
        }

        return arr_list;
    }

    public ArrayList<Balance> displayMonthData(String month) throws ParseException {

        ArrayList<Balance> list2 = new ArrayList<>();

        String Query = "SELECT * FROM " + TABLE_NAME;

        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        Cursor cur = sqLiteDatabase.rawQuery(Query, null);

        String endMonth = getTheMonth(month);
        DateFormat format2 = new SimpleDateFormat("MM");
        SimpleDateFormat format1 = new SimpleDateFormat("MM/dd/yyyy");

        if (cur.moveToFirst()) {
            do {
                Date date = format1.parse(cur.getString(3));
                String finalMonth = format2.format(date);

                if (finalMonth.equals(endMonth)) {
                    Balance in = new Balance(Float.parseFloat(cur.getString(2)));
                    list2.add(in);
                }
            } while (cur.moveToNext());

        }

        return list2;


    }

    public String getTheMonth(String month) {
        String endMonth = " ";
        switch (month) {
            case "January": {
                endMonth = "01";
                break;
            }
            case "February": {
                endMonth = "02";
                break;
            }
            case "March": {
                endMonth = "03";
                break;
            }
            case "April": {
                endMonth = "04";
                break;
            }
            case "May": {
                endMonth = "05";
                break;
            }
            case "June": {
                endMonth = "06";
                break;
            }
            case "July": {
                endMonth = "07";
                break;
            }
            case "August": {
                endMonth = "08";
                break;
            }
            case "September": {
                endMonth = "09";
                break;
            }
            case "October": {
                endMonth = "10";
                break;
            }
            case "November": {
                endMonth = "11";
                break;
            }
            case "December": {
                endMonth = "12";
                break;
            }

        }

        return endMonth;
    }
}


