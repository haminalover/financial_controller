package com.example.rocnikovka2;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.design.widget.TextInputLayout;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.formatter.IValueFormatter;
import com.github.mikephil.charting.utils.ViewPortHandler;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class Detailed_data_month extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {
    BarChart barChart;
    Spinner month_spinner;
    TextInputLayout txt_year;
    TextView final_year;
    DHelper2 data_helper;
    Toast tag;
    Button show;
    String month;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detailed_data);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        tag = Toast.makeText(this, "Write the year in the text field",Toast.LENGTH_LONG);



        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        month_spinner = (Spinner) findViewById(R.id.spinner);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.months, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        month_spinner.setAdapter(adapter);

        show = (Button) findViewById(R.id.data_show);

        barChart = (BarChart) findViewById(R.id.barChart);
        data_helper = new DHelper2(this);

        txt_year = (TextInputLayout) findViewById(R.id.text_layout_amount);
        final_year = (TextView) findViewById(R.id.final_year);



        month_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                 month = adapterView.getItemAtPosition(i).toString();

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        show.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ArrayList<Expense> arrayList = new ArrayList<Expense>();
                ArrayList<BarDataSet> arr_set = new ArrayList<>();
                String year = txt_year.getEditText().getText().toString();
                BarData barData = new BarData();
                if(!year.isEmpty()) {
                    try {
                        arrayList = data_helper.displayMonthYearData(month, year);

                        Map<String, Float> data_map = new HashMap<>();
                        ArrayList<BarEntry> barValues = new ArrayList<>();
                        for (Expense out : arrayList) {
                            boolean already_contains = false;
                            if (data_map.containsKey(out.getCategory())) {
                                data_map.replace(out.getCategory(), data_map.get(out.getCategory()) + out.getAmount());
                            } else {
                                data_map.put(out.getCategory(), out.getAmount());
                            }
                        }
                        int x = 0;

                        Random rnd = new Random();
                        int color = Color.argb(255, rnd.nextInt(256), rnd.nextInt(256), rnd.nextInt(256));

                        for (String key : data_map.keySet()) {
                            x++;
                            barValues.add(new BarEntry(x, data_map.get(key)));

                            BarDataSet barSet = new BarDataSet(barValues, key);
                            barSet.setColor(color);
                            barData.addDataSet(barSet);

                        }

                        barChart.setData(barData);
                        barChart.invalidate();

                    } catch (ParseException e) {
                        e.printStackTrace();
                    }
                }else tag.show();

            }
        });

    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.detailed_data, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_outcomes) {
            // Handle the camera action
            Intent i = new Intent(Detailed_data_month.this, Expenses_activity.class);
            startActivity(i);
        } else if (id == R.id.nav_home) {
            Intent i = new Intent(Detailed_data_month.this, MainActivity.class);
            startActivity(i);

        } else if (id == R.id.nav_data) {
            Intent i = new Intent(Detailed_data_month.this, History_data_activity.class);
            startActivity(i);

        } else if (id == R.id.nav_currency) {
            Intent i = new Intent(Detailed_data_month.this, Converter.class);
            startActivity(i);

        } else if (id == R.id.nav_income) {
            Intent i = new Intent(Detailed_data_month.this, Income_activity.class);
            startActivity(i);

        }
        else if (id == R.id.nav_detail) {
            Intent i = new Intent(Detailed_data_month.this, DataViewer.class);
            startActivity(i);
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    private class MyValueFormatter implements IValueFormatter {


        @Override
        public String getFormattedValue(float value, Entry entry, int dataSetIndex, ViewPortHandler viewPortHandler) {
            return value + "";
        }
    }
}
