package com.example.rocnikovka2;

public class Balance {

    static float bal;

    public Balance(float bal) {
        this.bal = bal;
    }

    static float getBalance() {

        return bal;
    }
}
