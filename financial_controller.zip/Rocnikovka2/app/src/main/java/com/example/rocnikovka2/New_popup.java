package com.example.rocnikovka2;

import android.app.Activity;
import android.os.Bundle;
import android.support.design.widget.TextInputLayout;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

public class New_popup extends Activity implements View.OnClickListener {
    Button data_add_button;
    TextView editText_category, editText_amount, database_display;
    TextInputLayout text_layout_category, text_layout_amount;
    private Calendar calendar;
    private SimpleDateFormat dateFormat;
    private String date;
    float amount;
    Spinner new_cat_spinner;
    ArrayList<String> categories;
    DHelper2 data_helper;
    Toast tag;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.new_popup);

        DisplayMetrics metrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(metrics);

        int width = metrics.widthPixels;
        int height = metrics.heightPixels;

        getWindow().setLayout((int) (width * .8), (int) (height * .6));

        tag = Toast.makeText(this, "Your amount field is empty!!", Toast.LENGTH_LONG);


        data_add_button = (Button) findViewById(R.id.pop_add_button);
        data_add_button.setOnClickListener(this);

        text_layout_amount = (TextInputLayout) findViewById(R.id.text_layout_am);
        text_layout_category = (TextInputLayout) findViewById(R.id.text_layout_category);

        editText_category = (TextView) findViewById(R.id.editText_category);
        editText_amount = (TextView) findViewById(R.id.editText_amount);
        database_display = (TextView) findViewById(R.id.pop_display);

        new_cat_spinner = (Spinner) findViewById(R.id.new_cat_spinner);

        data_helper = new DHelper2(this);

        categories = data_helper.getCategories();
        categories.remove(0);

        new_cat_spinner = (Spinner) findViewById(R.id.new_cat_spinner);
        ArrayAdapter<String> catAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, categories);
        new_cat_spinner.setAdapter(catAdapter);

        new_cat_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long id) {
                String category = adapterView.getItemAtPosition(i).toString();

                text_layout_category.getEditText().setText(category);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.pop_add_button: {
                if (!text_layout_amount.getEditText().getText().toString().isEmpty()) {
                    String str_amount = text_layout_amount.getEditText().getText().toString();
                    amount = Float.parseFloat(str_amount);
                    calendar = Calendar.getInstance();
                    dateFormat = new SimpleDateFormat("MM/dd/yyyy");
                    date = dateFormat.format(calendar.getTime());

                    Expense out = new Expense(date, text_layout_category.getEditText().getText().toString(), amount);
                    DHelper2 data_helper = new DHelper2(this);
                    data_helper.addData(out);
                    DHelper4 dh = new DHelper4(this);
                    float bal = dh.displayLastBalance();
                    bal -= amount;
                    Balance b = new Balance(bal);
                    dh.addData(b);

                } else tag.show();
                break;
            }

        }
    }
}
