package com.example.rocnikovka2;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.DisplayMetrics;
import android.util.Log;
import android.widget.TextView;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.interfaces.datasets.ILineDataSet;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class Add_popup extends Activity {

    LineChart lineChart;
    TextView txt_balance;
    DHelper4 data_helper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.add_popup);

        DisplayMetrics metrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(metrics);

        int width = metrics.widthPixels;
        int height = metrics.heightPixels;

        getWindow().setLayout((int) (width * .8), (int) (height * .6));

        data_helper = new DHelper4(this);


        txt_balance = (TextView) findViewById(R.id.txt_bl);
        setBalance(data_helper.displayLastBalance());


        ArrayList<Float> arr_bal = new ArrayList<>();
        arr_bal = data_helper.displayAllData();

        ArrayList<Entry> ent_list = new ArrayList<>();

        for(int x = 0; x <= arr_bal.size()-1;x++ ){

            ent_list.add(new Entry(x,arr_bal.get(x)));

        }


        lineChart = (LineChart) findViewById(R.id.lineChart);
        LineDataSet set = new LineDataSet(dataBalance(), "Balance");
        set.setColor(Color.BLUE);
        set.setHighLightColor(Color.BLUE);


        LineDataSet set2 = new LineDataSet(dataNull(), "Null");
        set2.setColor(Color.RED);
        set2.setHighLightColor(Color.BLUE);




        ArrayList<ILineDataSet> ilset = new ArrayList<>();
        ilset.add(set);
        ilset.add(set2);
        LineData ld = new LineData(ilset);

        lineChart.setData(ld);
        lineChart.invalidate();


    }

    private ArrayList<Entry> dataBalance() {
        ArrayList<Float> arr_bal = new ArrayList<>();
        arr_bal = data_helper.displayAllData();
        ArrayList<Entry> ent_list = new ArrayList<>();
        for(int x = 0; x <= arr_bal.size()-1;x++ ){
            ent_list.add(new Entry(x,arr_bal.get(x)));
        }
        return ent_list;
    }
    private ArrayList<Entry> dataNull() {
        ArrayList<Float> arr_bal = new ArrayList<>();
        arr_bal = data_helper.displayAllData();
        ArrayList<Entry> ent_list = new ArrayList<>();
        for(int x = 0; x <= arr_bal.size()-1;x++ ){
            ent_list.add(new Entry(x,0));
        }
        return ent_list;
    }



    public void setBalance(float bl) {

        if (bl < 0) {
            txt_balance.setTextColor(Color.RED);
        } else txt_balance.setTextColor(Color.BLUE);


        txt_balance.setText(bl + "");

    }
}
