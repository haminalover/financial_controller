package com.example.rocnikovka2;

import android.os.AsyncTask;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class ConversionHelper extends AsyncTask<Void, Void, Void> {
    String usd;
    String eur;
    String czk;
    String cny;
    String data = "";
    float CZK;
    float EUR;
    float JPY;
    float USD;
    float GBP;
    float AUD;

    @Override
    protected Void doInBackground(Void... voids) {
        try {
                URL url = new URL("https://prime.exchangerate-api.com/v5/996fca6f62f213bcc21d93a5/latest/USD");
            HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
            InputStream inputStream = httpURLConnection.getInputStream();
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
            String line = " ";
            while (line != null) {
                line = bufferedReader.readLine();
                data = data + line;
            }

            JSONObject reader = new JSONObject(data);
            USD = Float.parseFloat(reader.getJSONObject("conversion_rates").getString("USD"));
            EUR = Float.parseFloat(reader.getJSONObject("conversion_rates").getString("EUR"));
            CZK = Float.parseFloat(reader.getJSONObject("conversion_rates").getString("CZK"));
            JPY = Float.parseFloat(reader.getJSONObject("conversion_rates").getString("JPY"));
            AUD = Float.parseFloat(reader.getJSONObject("conversion_rates").getString("AUD"));
            GBP = Float.parseFloat(reader.getJSONObject("conversion_rates").getString("GBP"));




        } catch (MalformedURLException e) {

            Log.d("msg1", e.getMessage());

        } catch (IOException e) {

            Log.d("msg2", e.getMessage());

        } catch (JSONException e) {

            Log.d("msg3", e.getMessage());
        }
        return null;
    }

    @Override
    protected void onPostExecute(Void aVoid) {
        super.onPostExecute(aVoid);
        Log.d("msg", "hotovo");

        Converter.czk = this.CZK;
        Converter.eur = this.EUR;
        Converter.jpy = this.JPY;
        Converter.usd = this.USD;
        Converter.aud = this.AUD;
        Converter.gbp = this.GBP;


    }

    public String getCZK() {
        return czk;
    }

    public String getEUR() {
        return eur;
    }

    public String getCNY() {
        return cny;
    }
}


