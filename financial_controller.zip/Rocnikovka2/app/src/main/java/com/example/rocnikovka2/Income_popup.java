package com.example.rocnikovka2;

import android.app.Activity;
import android.os.Bundle;
import android.support.design.widget.TextInputLayout;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;


public class Income_popup extends Activity implements View.OnClickListener {
    Button data_add_button;
    TextView editText_category, editText_amount, database_display;
    TextInputLayout text_layout_category, text_layout_amount;
    private TextView dateTimeDisplay;
    private Calendar calendar;
    private SimpleDateFormat dateFormat;
    private String date;
    float amount;
    Toast tag;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.income_popup);

        DisplayMetrics metrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(metrics);

        int width = metrics.widthPixels;
        int height = metrics.heightPixels;

        getWindow().setLayout((int) (width * .8), (int) (height * .6));

        data_add_button = (Button) findViewById(R.id.pop_add_button);
        data_add_button.setOnClickListener(this);

        text_layout_amount = (TextInputLayout) findViewById(R.id.text_layout_am);
        text_layout_category = (TextInputLayout) findViewById(R.id.text_layout_category);

        editText_category = (TextView) findViewById(R.id.editText_category);
        editText_amount = (TextView) findViewById(R.id.editText_amount);
        database_display = (TextView) findViewById(R.id.pop_display);


    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.pop_add_button: {
                if (!text_layout_amount.getEditText().getText().toString().isEmpty()) {

                    String str_amount = text_layout_amount.getEditText().getText().toString();
                    amount = Float.parseFloat(str_amount);
                    calendar = Calendar.getInstance();
                    dateFormat = new SimpleDateFormat("MM/dd/yyyy");
                    date = dateFormat.format(calendar.getTime());

                    Income in = new Income(date, text_layout_category.getEditText().getText().toString(), amount);

                    DHelper3 data_helper = new DHelper3(this);
                    data_helper.addData(in);
                    DHelper4 dh = new DHelper4(this);
                    float bal = dh.displayLastBalance();
                    bal += amount;
                    Balance b = new Balance(bal);
                    dh.addData(b);

                    break;
                } else tag.show();
            }
        }
    }
}

