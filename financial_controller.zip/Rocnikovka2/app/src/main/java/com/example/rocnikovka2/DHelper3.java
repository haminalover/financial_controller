package com.example.rocnikovka2;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class DHelper3 extends SQLiteOpenHelper {
    private static final String TABLE_NAME = "incomesHistory";
    private static final String col1 = "income_id";
    private static final String col2 = "income_category";
    private static final String col3 = "income_amount";
    private static final String col4 = "income_date";


    public DHelper3(Context context) {
        super(context, TABLE_NAME, null, 1);


    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        String createTable = "CREATE TABLE " + TABLE_NAME + "(" + col1 + "INTEGER PRIMARY KEY, " + col2 + " TEXT," + col3 + " TEXT," + col4 + " TEXT" + ")";
        sqLiteDatabase.execSQL(createTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }

    public void addData(Income income) {

        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(col2, income.getCategory());
        contentValues.put(col3, income.getAmount());
        contentValues.put(col4, income.getDate());

        sqLiteDatabase.insert(TABLE_NAME, null, contentValues);
        sqLiteDatabase.close();
    }

    public String displayData(int id) {
        SQLiteDatabase sqLiteDatabase = this.getReadableDatabase();

        Cursor cursor = sqLiteDatabase.query(TABLE_NAME, new String[]{col1, col2, col3, col4}, col1 + "=?", new String[]{String.valueOf(id)}, null, null, null, null);
        if (cursor != null) {
            cursor.moveToFirst();
        }
        String display = Integer.parseInt(cursor.getString(0)) + " " + cursor.getString(1) + " " + Integer.parseInt(cursor.getString(2));
        return display;
    }

    public ArrayList<Income> displayAllData() {
        ArrayList<Income> list = new ArrayList<>();

        String selectQuery = "SELECT * FROM " + TABLE_NAME;

        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        Cursor cursor = sqLiteDatabase.rawQuery(selectQuery, null);

        if (cursor.moveToFirst()) {
            do {
                Income in = new Income(cursor.getString(3), cursor.getString(1), Float.parseFloat(cursor.getString(2)));
                list.add(in);

            } while (cursor.moveToNext());

        }

        return list;

    }

    public ArrayList<Income> displayMonthData(String month) throws ParseException {

        ArrayList<Income> list2 = new ArrayList<>();

        String Query = "SELECT * FROM " + TABLE_NAME;

        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        Cursor cur = sqLiteDatabase.rawQuery(Query, null);

        String endMonth = getTheMonth(month);
        DateFormat format2 = new SimpleDateFormat("MM");
        SimpleDateFormat format1 = new SimpleDateFormat("MM/dd/yyyy");

        if (cur.moveToFirst()) {
            do {
                Date date = format1.parse(cur.getString(3));
                String finalMonth = format2.format(date);

                if (finalMonth.equals(endMonth)) {
                    Income in = new Income(cur.getString(3), cur.getString(1), Float.parseFloat(cur.getString(2)));
                    list2.add(in);
                }
            } while (cur.moveToNext());

        }

        return list2;


    }

    public String getTheMonth(String month) {
        String endMonth = " ";
        switch (month) {
            case "January": {
                endMonth = "01";
                break;
            }
            case "February": {
                endMonth = "02";
                break;
            }
            case "March": {
                endMonth = "03";
                break;
            }
            case "April": {
                endMonth = "04";
                break;
            }
            case "May": {
                endMonth = "05";
                break;
            }
            case "June": {
                endMonth = "06";
                break;
            }
            case "July": {
                endMonth = "07";
                break;
            }
            case "August": {
                endMonth = "08";
                break;
            }
            case "September": {
                endMonth = "09";
                break;
            }
            case "October": {
                endMonth = "10";
                break;
            }
            case "November": {
                endMonth = "11";
                break;
            }
            case "December": {
                endMonth = "12";
                break;
            }

        }

        return endMonth;
    }
}


