package com.example.rocnikovka2;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.widget.TextView;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.interfaces.datasets.ILineDataSet;
import com.github.mikephil.charting.utils.ColorTemplate;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import static android.graphics.Color.WHITE;

public class Monthstats_popup extends Activity {

    LineChart lineChart;
    TextView txt_balance;
    DHelper2 data_helper;
    BarChart barChart;
    Calendar calendar;
    SimpleDateFormat dateFormat, dateFormat2;
    String date, lastMonth, currYear;
    TextView expense;
    int year;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.monthstats_popup_layout);

        DisplayMetrics metrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(metrics);

        int width = metrics.widthPixels;
        int height = metrics.heightPixels;

        getWindow().setLayout((int) (width * .8), (int) (height * .6));

        barChart = (BarChart) findViewById(R.id.stats_barchart);
        data_helper = new DHelper2(this);

        txt_balance = (TextView) findViewById(R.id.txt_bl);


        calendar = Calendar.getInstance();
        dateFormat = new SimpleDateFormat("MM");
        dateFormat2 = new SimpleDateFormat("yyyy");
        date = dateFormat.format(calendar.getTime());
        currYear = dateFormat2.format(calendar.getTime());

        getLastMonth(date,currYear);

        String year2 = year + "";
        ArrayList<Expense> arrayList = new ArrayList<Expense>();
        ArrayList<BarDataSet> arr_set = new ArrayList<>();
        BarData barData = new BarData();
            try {
                arrayList = data_helper.displayMonthYearData(lastMonth, year2);

                Map<String, Float> data_map = new HashMap<>();
                ArrayList<BarEntry> barValues = new ArrayList<>();
                for (Expense out : arrayList) {
                    if (data_map.containsKey(out.getCategory())) {
                        data_map.replace(out.getCategory(), data_map.get(out.getCategory()) + out.getAmount());
                    } else {
                        data_map.put(out.getCategory(), out.getAmount());
                    }
                }
                int x = 0;

                Random rnd = new Random();
                int color = Color.argb(255, rnd.nextInt(256), rnd.nextInt(256), rnd.nextInt(256));

                for (String key : data_map.keySet()) {
                    x++;
                    barValues.add(new BarEntry(x, data_map.get(key)));

                    BarDataSet barSet = new BarDataSet(barValues, key);
                    barSet.setColor(color);
                    barData.addDataSet(barSet);

                }

                barChart.setData(barData);
                barChart.invalidate();

                expense = (TextView) findViewById(R.id.stat_expense);

                expense.setText("Your expenses were " + data_helper.displayMonthCategoryYearData(lastMonth,year2,"Expenses in all categories"));



            } catch (ParseException e) {
                e.printStackTrace();
            }


    }

    public void getLastMonth (String currMonth, String y){
        switch (currMonth) {
            case "01": {
                 lastMonth = "December";
                 year = Integer.parseInt(y)-1;
                break;
            }
            case "02": {
                lastMonth = "January";
                year = Integer.parseInt(y);
                break;
            }
            case "03": {
                lastMonth = "February";
                year = Integer.parseInt(y);
                break;
            }
            case "04": {
                lastMonth = "March";
                year = Integer.parseInt(y);
                break;
            }
            case "05": {
                lastMonth = "April";
                year = Integer.parseInt(y);
                break;
            }
            case "06": {
                lastMonth = "May";
                year = Integer.parseInt(y);
                break;
            }
            case "07": {
                lastMonth = "June";
                year = Integer.parseInt(y);
                break;
            }
            case "08": {
                lastMonth = "July";
                year = Integer.parseInt(y);
                break;
            }
            case "09": {
                lastMonth = "August";
                year = Integer.parseInt(y);
                break;
            }
            case "10": {
                lastMonth = "September";
                year = Integer.parseInt(y);
                break;
            }
            case "11": {
                lastMonth = "October";
                year = Integer.parseInt(y);
                break;
            }
            case "12": {
                lastMonth = "November";
                year = Integer.parseInt(y);
                break;
            }

        }
    }

}

