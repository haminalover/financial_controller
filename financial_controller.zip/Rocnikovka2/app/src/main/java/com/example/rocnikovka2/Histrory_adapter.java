package com.example.rocnikovka2;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class Histrory_adapter extends BaseAdapter {

    Context context;
    ArrayList<Expense> outcomeList;

    public Histrory_adapter(Context context, ArrayList<Expense> outcomeList) {

        this.context = context;
        this.outcomeList = outcomeList;

    }

    @Override
    public int getCount() {
        return this.outcomeList.size();
    }

    @Override
    public Object getItem(int position) {
        return outcomeList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {


        convertView = LayoutInflater.from(this.context).inflate(R.layout.data_row, parent, false);
        TextView t_date = (TextView) convertView.findViewById(R.id.date_txt);
        TextView t_category = (TextView) convertView.findViewById(R.id.category_txt);
        TextView t_amount = (TextView) convertView.findViewById(R.id.amount_txt);


        Expense outcome = outcomeList.get(position);

        t_date.setText(outcome.getDate());
        t_category.setText(outcome.getCategory());
        t_amount.setText("-" + String.valueOf(outcome.getAmount()));


        return convertView;

    }
}
