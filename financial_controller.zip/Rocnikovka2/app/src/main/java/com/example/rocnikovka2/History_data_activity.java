package com.example.rocnikovka2;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.TextInputEditText;
import android.support.design.widget.TextInputLayout;
import android.util.Log;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import java.text.ParseException;
import java.util.ArrayList;

public class History_data_activity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener, View.OnClickListener {


    ListView listView;
    DHelper2 data_helper;
    ArrayList<Expense> outcomeArrayList;
    Histrory_adapter histrory_adapter;
    String month;
    Button find;
    TextInputLayout txt_lay;
    TextInputEditText txt_year;
    Toast tag;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history_data_activity);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        tag = Toast.makeText(this, "Write the year in the text field",Toast.LENGTH_LONG);


        data_helper = new DHelper2(this);


        Spinner months_spinner = (Spinner) findViewById(R.id.months_spinner);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.months, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        months_spinner.setAdapter(adapter);

        months_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                month = adapterView.getItemAtPosition(i).toString();

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        txt_lay = (TextInputLayout) findViewById(R.id.history_textLayout);
        txt_year = (TextInputEditText) findViewById(R.id.history_year);

        find = (Button) findViewById(R.id.his_btn);
        find.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    if(!txt_lay.getEditText().getText().toString().isEmpty()) {
                        listView = (ListView) findViewById(R.id.list_view);
                        loadDataInListView(data_helper.displayMonthYearData(month, txt_lay.getEditText().getText().toString()));
                    }else tag.show();
                } catch (ParseException e) {
                }
            }
        });

    }

    private void loadDataInListView(ArrayList<Expense> arrayList) {


        histrory_adapter = new Histrory_adapter(this, arrayList);
        listView.setAdapter(histrory_adapter);
        histrory_adapter.notifyDataSetChanged();

    }

    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();


        if (id == R.id.nav_outcomes) {
            // Handle the camera action
            Intent i = new Intent(History_data_activity.this, Expenses_activity.class);
            startActivity(i);
        } else if (id == R.id.nav_home) {
            Intent i = new Intent(History_data_activity.this, MainActivity.class);
            startActivity(i);

        } else if (id == R.id.nav_data) {
            Intent i = new Intent(History_data_activity.this, History_data_activity.class);
            startActivity(i);

        } else if (id == R.id.nav_currency) {
            Intent i = new Intent(History_data_activity.this, Converter.class);
            startActivity(i);

        } else if (id == R.id.nav_income) {
            Intent i = new Intent(History_data_activity.this, Income_activity.class);
            startActivity(i);

        }
        else if (id == R.id.nav_detail) {
            Intent i = new Intent(History_data_activity.this, DataViewer.class);
            startActivity(i);
        }
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {


        }
    }
}
