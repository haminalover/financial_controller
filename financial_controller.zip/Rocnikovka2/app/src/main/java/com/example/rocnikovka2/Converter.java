package com.example.rocnikovka2;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.support.design.widget.TextInputLayout;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class Converter extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    private TextInputLayout txt_amount;
    private Button convert_button;
    private TextView result_amount, txt_rates;
    static float usd;
    static float czk;
    static float jpy;
    static float eur;
    static float aud;
    static float gbp;
    static float firstRate = czk;
    static float secondRate = czk;
    String firstCurrency, secondCurrency;
    Toast tag;

    @SuppressLint("WrongThread")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_converter);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        tag = Toast.makeText(this, "Write the amount in the text field",Toast.LENGTH_LONG);


        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        Spinner cur1_spinner = (Spinner) findViewById(R.id.cur1_spinner);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.currencies, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        cur1_spinner.setAdapter(adapter);
        cur1_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                String currency = adapterView.getItemAtPosition(i).toString();
                if (currency.equals("USD")) {
                    firstRate = usd;
                } else if (currency.equals("CZK")) {
                    firstRate = czk;
                } else if (currency.equals("JPY")) {
                    firstRate = jpy;
                } else if (currency.equals("EUR")) {
                    firstRate = eur;
                }

                firstCurrency = currency;
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        Spinner cur2_spinner = (Spinner) findViewById(R.id.cur2_spinner);
        ArrayAdapter<CharSequence> adapter2 = ArrayAdapter.createFromResource(this, R.array.currencies, android.R.layout.simple_spinner_item);
        adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        cur2_spinner.setAdapter(adapter2);
        cur2_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                String currency = adapterView.getItemAtPosition(i).toString();
                if (currency.equals("USD")) {
                    secondRate = usd;
                } else if (currency.equals("CZK")) {
                    secondRate = czk;
                } else if (currency.equals("JPY")) {
                    secondRate = jpy;
                } else if (currency.equals("EUR")) {
                    secondRate = eur;
                }

                secondCurrency = currency;
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        askForPermission(Manifest.permission.INTERNET, 1);

        ConversionHelper conHelper = new ConversionHelper();
        conHelper.execute();

        txt_amount = (TextInputLayout) findViewById(R.id.text_layout_amount);

        txt_rates = (TextView) findViewById(R.id.txt_rates);

        txt_rates.setText("1.0 EUR is " + eur + " USD" + "\n" + "1.0 CZK is " + czk + " USD" + "\n" + "1.0 AUD is " + aud + " USD" + "\n" + "1.0 JPY is " + jpy + " USD" + "\n"+ "1.0 GBP is " + gbp + " USD");

        convert_button = (Button) findViewById(R.id.convert_button);

        result_amount = (TextView) findViewById(R.id.result_amount);


        convert_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(!txt_amount.getEditText().getText().toString().isEmpty()){
                    String sa = txt_amount.getEditText().getText().toString();
                    Float amount = Float.parseFloat(sa);
                    float result = (amount / firstRate) * secondRate;
                    result_amount.setText(amount+ " " + firstCurrency + " is " + result + " " + secondCurrency);
                }else tag.show();

            }
        });


    }

    private void askForPermission(String permission, int requestCode) {
        if (ContextCompat.checkSelfPermission(Converter.this, permission) != PackageManager.PERMISSION_GRANTED) {


            if (ActivityCompat.shouldShowRequestPermissionRationale(Converter.this, permission)) {


                ActivityCompat.requestPermissions(Converter.this, new String[]{permission}, requestCode);

            } else {

                ActivityCompat.requestPermissions(Converter.this, new String[]{permission}, requestCode);
            }
        }
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.conventer, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }


    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_outcomes) {
            // Handle the camera action
            Intent i = new Intent(Converter.this, Expenses_activity.class);
            startActivity(i);
        } else if (id == R.id.nav_home) {
            Intent i = new Intent(Converter.this, MainActivity.class);
            startActivity(i);

        } else if (id == R.id.nav_data) {
            Intent i = new Intent(Converter.this, History_data_activity.class);
            startActivity(i);

        } else if (id == R.id.nav_currency) {
            Intent i = new Intent(Converter.this, Converter.class);
            startActivity(i);

        } else if (id == R.id.nav_income) {
            Intent i = new Intent(Converter.this, Income_activity.class);
            startActivity(i);

        }
        else if (id == R.id.nav_detail) {
            Intent i = new Intent(Converter.this, Detailed_data_month.class);
            startActivity(i);
        }


        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
}
