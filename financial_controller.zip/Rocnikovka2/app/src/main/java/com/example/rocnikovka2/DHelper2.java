package com.example.rocnikovka2;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class DHelper2 extends SQLiteOpenHelper {

    private static final String TABLE_NAME = "outcomesHistory";
    private static final String col1 = "id";
    private static final String col2 = "category";
    private static final String col3 = "amount";
    private static final String col4 = "date";


    public DHelper2(Context context) {
        super(context, TABLE_NAME, null, 1);


    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        String createTable = "CREATE TABLE " + TABLE_NAME + "(" + col1 + "INTEGER PRIMARY KEY, " + col2 + " TEXT," + col3 + " TEXT," + col4 + " TEXT" + ")";
        sqLiteDatabase.execSQL(createTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }

    public void addData(Expense outcome) {

        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(col2, outcome.getCategory());
        contentValues.put(col3, outcome.getAmount());
        contentValues.put(col4, outcome.getDate());

        sqLiteDatabase.insert(TABLE_NAME, null, contentValues);
        sqLiteDatabase.close();
    }

    public String displayData(int id) {
        SQLiteDatabase sqLiteDatabase = this.getReadableDatabase();

        Cursor cursor = sqLiteDatabase.query(TABLE_NAME, new String[]{col1, col2, col3, col4}, col1 + "=?", new String[]{String.valueOf(id)}, null, null, null, null);
        if (cursor != null) {
            cursor.moveToFirst();
        }
        String display = Integer.parseInt(cursor.getString(0)) + " " + cursor.getString(1) + " " + Integer.parseInt(cursor.getString(2));
        return display;
    }

    public ArrayList<Expense> displayAllData() {
        ArrayList<Expense> list = new ArrayList<>();

        String selectQuery = "SELECT * FROM " + TABLE_NAME;

        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        Cursor cursor = sqLiteDatabase.rawQuery(selectQuery, null);

        if (cursor.moveToFirst()) {
            do {
                Expense out = new Expense(cursor.getString(3), cursor.getString(1), Float.parseFloat(cursor.getString(2)));
                list.add(out);
            } while (cursor.moveToNext());

        }

        return list;

    }

    public ArrayList<Expense> displayMonthData(String month) throws ParseException {

        ArrayList<Expense> list2 = new ArrayList<>();

        String Query = "SELECT * FROM " + TABLE_NAME;

        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        Cursor cur = sqLiteDatabase.rawQuery(Query, null);

        String endMonth = getTheMonth(month);
        DateFormat format2 = new SimpleDateFormat("MM");
        SimpleDateFormat format1 = new SimpleDateFormat("MM/dd/yyyy");

        if (cur.moveToFirst()) {
            do {
                Date date = format1.parse(cur.getString(3));
                String finalMonth = format2.format(date);

                if (finalMonth.equals(endMonth)) {
                    Expense out = new Expense(cur.getString(3), cur.getString(1), Float.parseFloat(cur.getString(2)));
                    list2.add(out);
                }
            } while (cur.moveToNext());

        }

        return list2;


    }

    public ArrayList<String> getCategories(){
        ArrayList<String> categories = new ArrayList<>();
        categories.add("Expenses in all categories");
        String selectQuery = "SELECT * FROM " + TABLE_NAME;

        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        Cursor cursor = sqLiteDatabase.rawQuery(selectQuery, null);

        if (cursor.moveToFirst()) {
            do {
                if(!categories.contains(cursor.getString(1))) {
                    categories.add(cursor.getString(1));
                }
            } while (cursor.moveToNext());
        }

        return categories;
    }
    public ArrayList<Expense> displayMonthYearData(String month, String year) throws ParseException {

        ArrayList<Expense> list2 = new ArrayList<>();

        String Query = "SELECT * FROM " + TABLE_NAME;

        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        Cursor cur = sqLiteDatabase.rawQuery(Query, null);

        String endMonth = getTheMonth(month);

        DateFormat format2 = new SimpleDateFormat("MM");
        DateFormat format3 = new SimpleDateFormat("yyyy");
        SimpleDateFormat format1 = new SimpleDateFormat("MM/dd/yyyy");

        if (cur.moveToFirst()) {
            do {
                Date date = format1.parse(cur.getString(3));
                String finalMonth = format2.format(date);
                String finalYear = format3.format(date);

                if (finalMonth.equals(endMonth)&&finalYear.equals(year)) {
                    Expense out = new Expense(cur.getString(3), cur.getString(1), Float.parseFloat(cur.getString(2)));
                    list2.add(out);
                }
            } while (cur.moveToNext());

        }

        return list2;


    }
    public int displayMonthCategoryYearData(String month, String year,String category) throws ParseException {

        ArrayList<Expense> list2 = new ArrayList<>();

        String Query = "SELECT * FROM " + TABLE_NAME;

        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        Cursor cur = sqLiteDatabase.rawQuery(Query, null);

        String endMonth = getTheMonth(month);
        DateFormat format2 = new SimpleDateFormat("MM");
        DateFormat format3 = new SimpleDateFormat("yyyy");
        SimpleDateFormat format1 = new SimpleDateFormat("MM/dd/yyyy");
        int result=0;

        if (cur.moveToFirst()) {
            do {
                if(category.equals("Expenses in all categories")){
                    Date date = format1.parse(cur.getString(3));
                    String cat = cur.getString(1);
                    String finalMonth = format2.format(date);
                    String finalYear = format3.format(date);
                    if (finalMonth.equals(endMonth) && finalYear.equals(year) ) {
                        Expense out = new Expense(cur.getString(3), cur.getString(1), Float.parseFloat(cur.getString(2)));
                        result+=out.getAmount();
                    }
                } else {
                    Date date = format1.parse(cur.getString(3));
                    String cat = cur.getString(1);
                    String finalMonth = format2.format(date);
                    String finalYear = format3.format(date);

                    if (finalMonth.equals(endMonth) && finalYear.equals(year) && category.equals(cat)) {
                        Expense out = new Expense(cur.getString(3), cur.getString(1), Float.parseFloat(cur.getString(2)));
                        result+=out.getAmount();
                    }
                }
            } while (cur.moveToNext());

        }

        return result;


    }

    public String getTheMonth(String month) {

        String endMonth = "";
        switch (month) {
            case "January": {
                endMonth = "01";
                break;
            }
            case "February": {
                endMonth = "02";
                break;
            }
            case "March": {
                endMonth = "03";
                break;
            }
            case "April": {
                endMonth = "04";
                break;
            }
            case "May": {
                endMonth = "05";
                break;
            }
            case "June": {
                endMonth = "06";
                break;
            }
            case "July": {
                endMonth = "07";
                break;
            }
            case "August": {
                endMonth = "08";
                break;
            }
            case "September": {
                endMonth = "09";
                break;
            }
            case "October": {
                endMonth = "10";
                break;
            }
            case "November": {
                endMonth = "11";
                break;
            }
            case "December": {
                endMonth = "12";
                break;
            }

        }

        return endMonth;
    }
}

