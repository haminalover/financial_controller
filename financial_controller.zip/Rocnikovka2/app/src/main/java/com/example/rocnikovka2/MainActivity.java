package com.example.rocnikovka2;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

public class MainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener, View.OnClickListener {

    Button show_button;
    static float balance;
    DHelper4 data_helper;
    ImageButton main_outcome, main_income, main_detail, main_data, main_converter;
    Calendar calendar;
    SimpleDateFormat dateFormat;
    String date;
    String newMonth;
    String month = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        Boolean firstRun = getSharedPreferences("PREFERENCE", MODE_PRIVATE).getBoolean("firstrun", true);

        calendar = Calendar.getInstance();
        dateFormat = new SimpleDateFormat("MM");
        date = dateFormat.format(calendar.getTime());



        data_helper = new DHelper4(this);

        main_converter = (ImageButton) findViewById(R.id.main_converter);
        main_income = (ImageButton) findViewById(R.id.main_income);
        main_outcome = (ImageButton) findViewById(R.id.main_outcome);
        main_data = (ImageButton) findViewById(R.id.main_data);
        main_detail = (ImageButton) findViewById(R.id.main_detail);
        show_button = (Button) findViewById(R.id.show_button);

        main_outcome.setOnClickListener(this);
        main_income.setOnClickListener(this);
        main_detail.setOnClickListener(this);
        main_data.setOnClickListener(this);
        main_converter.setOnClickListener(this);
        show_button.setOnClickListener(this);

        //Zjišťuje zda se jedná o první spuštění aplikace
        if (firstRun) {
            Balance bal = new Balance(0);
            data_helper.addData(bal);
            getSharedPreferences("PREFERENCE", MODE_PRIVATE).edit().putBoolean("firstrun", false).commit();
            month = getSharedPreferences("MONTH2",MODE_PRIVATE).getString("month2",date + "");
        }

        balance = data_helper.displayLastBalance();
        setBalance(balance);

        //Zjišťuje jestli není nový měsíc
        if(!getSharedPreferences("MONTH2",MODE_PRIVATE).getString("month2",date + "").equals(date)){

            Intent i = new Intent(MainActivity.this, Monthstats_popup.class);
            startActivity(i);

            getSharedPreferences("MONTH2",MODE_PRIVATE).edit().putString("month2",date + "").commit();
            Toast.makeText(this , "New month!!",Toast.LENGTH_LONG).show();

        }


    }

    public void setBalance(float bl) {
        if (bl < 0) {
            show_button.setTextColor(Color.RED);
        } else show_button.setTextColor(Color.BLUE);
        show_button.setText(bl + "");
    }

    @Override
    public void onResume() {
        super.onResume();

        setBalance(balance);
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_outcomes) {
            // Handle the camera action
            Intent i = new Intent(MainActivity.this, Expenses_activity.class);
            startActivity(i);
        } else if (id == R.id.nav_home) {
            Intent i = new Intent(MainActivity.this, MainActivity.class);
            startActivity(i);

        } else if (id == R.id.nav_data) {
            Intent i = new Intent(MainActivity.this, History_data_activity.class);
            startActivity(i);

        } else if (id == R.id.nav_currency) {
            Intent i = new Intent(MainActivity.this, Converter.class);
            startActivity(i);

        } else if (id == R.id.nav_income) {
            Intent i = new Intent(MainActivity.this, Income_activity.class);
            startActivity(i);

        } else if (id == R.id.nav_detail) {
            Intent i = new Intent(MainActivity.this, DataViewer.class);
            startActivity(i);
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.main_outcome: {
                Intent i = new Intent(MainActivity.this, Expenses_activity.class);
                startActivity(i);
                break;
            }
            case R.id.main_income: {
                Intent i = new Intent(MainActivity.this, Income_activity.class);
                startActivity(i);
                break;
            }
            case R.id.main_data: {
                Intent i = new Intent(MainActivity.this, History_data_activity.class);
                startActivity(i);
                break;
            }
            case R.id.main_detail: {
                Intent i = new Intent(MainActivity.this, DataViewer.class);
                startActivity(i);
                break;
            }
            case R.id.main_converter: {
                Intent i = new Intent(MainActivity.this, Converter.class);
                startActivity(i);
                break;
            }
            case R.id.show_button: {
                Intent i = new Intent(MainActivity.this, Add_popup.class);
                startActivity(i);
                break;
            }

        }
    }
}
